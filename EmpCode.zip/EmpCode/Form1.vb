﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim empName, birthMonth, monthCode, depName, depCode, empCode As String
        empName = txtLast.Text.ToUpper.Substring(0, 3)
        birthMonth = txtMonth.Text.ToLower
        depName = txtDep.Text.ToLower
        depCode = DepNum(depName)
        monthCode = MonthNum(birthMonth)
        empCode = empName & monthCode & depCode
        outPut(empCode)
    End Sub

    Function DepNum(x As String) As String
        Dim y As String
        Select Case x
            Case "accounting"
                y = "101"
            Case "marketing"
                y = "102"
            Case "human resources"
                y = "103"
            Case "sales"
                y = "104"
            Case "research"
                y = "105"
        End Select
        Return y
    End Function

    Function MonthNum(m As String) As String
        Dim o As String
        Select Case m
            Case "january"
                o = "101"
            Case "february"
                o = "102"
            Case "march"
                o = "103"
            Case "april"
                o = "104"
            Case "may"
                o = "105"
            Case "june"
                o = "106"
            Case "july"
                o = "107"
            Case "august"
                o = "108"
            Case "september"
                o = "109"
            Case "october"
                o = "110"
            Case "november"
                o = "111"
            Case "december"
                o = "112"
        End Select
        Return o
    End Function

    Sub outPut(y As String)
        lstBox.Items.Add("Your Employee Code is -")
        lstBox.Items.Add(y)
    End Sub

End Class
