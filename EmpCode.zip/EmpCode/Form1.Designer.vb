﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblLast = New System.Windows.Forms.Label()
        Me.lblMonth = New System.Windows.Forms.Label()
        Me.lblDep = New System.Windows.Forms.Label()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtMonth = New System.Windows.Forms.TextBox()
        Me.txtDep = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.lstBox = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lblLast
        '
        Me.lblLast.AutoSize = True
        Me.lblLast.Location = New System.Drawing.Point(40, 29)
        Me.lblLast.Name = "lblLast"
        Me.lblLast.Size = New System.Drawing.Size(58, 13)
        Me.lblLast.TabIndex = 0
        Me.lblLast.Text = "Last Name"
        '
        'lblMonth
        '
        Me.lblMonth.AutoSize = True
        Me.lblMonth.Location = New System.Drawing.Point(40, 68)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(61, 13)
        Me.lblMonth.TabIndex = 1
        Me.lblMonth.Text = "Birth Month"
        '
        'lblDep
        '
        Me.lblDep.AutoSize = True
        Me.lblDep.Location = New System.Drawing.Point(40, 101)
        Me.lblDep.Name = "lblDep"
        Me.lblDep.Size = New System.Drawing.Size(62, 13)
        Me.lblDep.TabIndex = 2
        Me.lblDep.Text = "Department"
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(105, 29)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(100, 20)
        Me.txtLast.TabIndex = 3
        '
        'txtMonth
        '
        Me.txtMonth.Location = New System.Drawing.Point(105, 68)
        Me.txtMonth.Name = "txtMonth"
        Me.txtMonth.Size = New System.Drawing.Size(100, 20)
        Me.txtMonth.TabIndex = 4
        '
        'txtDep
        '
        Me.txtDep.Location = New System.Drawing.Point(105, 101)
        Me.txtDep.Name = "txtDep"
        Me.txtDep.Size = New System.Drawing.Size(100, 20)
        Me.txtDep.TabIndex = 5
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(43, 164)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(162, 23)
        Me.btnCalc.TabIndex = 6
        Me.btnCalc.Text = "Calculate Code"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'lstBox
        '
        Me.lstBox.FormattingEnabled = True
        Me.lstBox.Location = New System.Drawing.Point(43, 209)
        Me.lstBox.Name = "lstBox"
        Me.lstBox.Size = New System.Drawing.Size(162, 95)
        Me.lstBox.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(248, 450)
        Me.Controls.Add(Me.lstBox)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtDep)
        Me.Controls.Add(Me.txtMonth)
        Me.Controls.Add(Me.txtLast)
        Me.Controls.Add(Me.lblDep)
        Me.Controls.Add(Me.lblMonth)
        Me.Controls.Add(Me.lblLast)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblLast As Label
    Friend WithEvents lblMonth As Label
    Friend WithEvents lblDep As Label
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtMonth As TextBox
    Friend WithEvents txtDep As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents lstBox As ListBox
End Class
